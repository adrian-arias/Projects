//////////////////////////////////////////////////////////////////
//Original Author: Adrian Arias
//Date Created: 8/27/2020
//Version: Alpha Version
//Date Last Modified: 9/18/2020
//Modified by: Adrian Arias
//Modification log: Added mod log and javaScript w/libraries
//////////////////////////////////////////////////////////////////

"use strict";
var $ = function (id) {
  return document.getElementById(id);
};

var navigate = {
  showForm: function () {
    $("registration_form").setAttribute("class", "show");
    $("registration_result").setAttribute("class", "hide");
  },
  showResults: function () {
    $("registration_form").setAttribute("class", "hide");
    $("registration_result").setAttribute("class", "show");
  }
};
