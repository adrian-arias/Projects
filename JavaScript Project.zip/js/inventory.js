//////////////////////////////////////////////////////////////////
//Original Author: Adrian Arias
//Date Created: 8/27/2020
//Version: Alpha Version
//Date Last Modified: 9/11/2020
//Modified by: Adrian Arias
//Modification log: Added mod log and task
//////////////////////////////////////////////////////////////////
"use strict";
var $ = function (id) {
  return document.getElementById(id);
};

var tasks = [];
var sortDirection = "ASC";

var displayTaskList = function () {
  var list = "";
  if (tasks.length === 0) {
    var storage = localStorage.getItem("tasks") || "";
    if (storage.length > 0) {
      tasks = storage.split("|");
    }
  }
  if (tasks.length > 0) {
    if (sortDirection === "ASC") {
      tasks.sort();
    } else {
      tasks.reverse();
    }
    list = tasks.join("\n");
  }
  $("task_list").value = list;
  $("task").focus();
  var name = sessionStorage.name || "";
  $("name").firstChild.nodeValue = name.length === 0 ? "" : name + "'s ";
};

var addToTaskList = function () {
  var task = $("task");
  if (task.value === "") {
    alert("Please enter a task.");
  } else {
    tasks.push(task.value);
    localStorage.tasks = tasks.join("|");
    task.value = "";
    displayTaskList();
  }
};

var clearTaskList = function () {
  tasks.length = 0;
  localStorage.setItem("tasks", "");
  $("task_list").value = "";
  $("task").focus();
};

var deleteTask = function () {
  var index = parseInt(prompt("Enter the index number of the task to delete."));
  if (!isNaN(index)) {
    tasks.splice(index, 1);
    localStorage.tasks = tasks.join("|");
    displayTaskList();
  }
};

var importantTasks = function (element) {
  var lower = element.toLowerCase();
  var index = lower.indexOf("important!");
  return index > -1;
};

window.onload = function () {
  $("add_task").onclick = addToTaskList;
  $("clear_tasks").onclick = clearTaskList;
  $("delete_task").onclick = deleteTask;

  displayTaskList();
};
