//////////////////////////////////////////////////////////////////
//Original Author: Adrian Arias
//Date Created: 8/27/2020
//Version: Alpha Version
//Date Last Modified: 9/11/2020
//Modified by: Adrian Arias
//Modification log: Added mod log
//////////////////////////////////////////////////////////////////
"use strict";
var registerForm;

window.onload = function () {
  //create validation object and set field messages
  registerForm = new RegisterForm();
  registerForm.resetForm();

  $("register").onclick = function () {
    if (registerForm.validateForm()) {
      // $("registration_form").submit();
      navigate.showResults();
    }
  };

  $("reset").onclick = function () {
    registerForm.resetForm();
  };

  $("back").onclick = function () {
    navigate.showForm();
    registerForm.resetForm();
  };
};
