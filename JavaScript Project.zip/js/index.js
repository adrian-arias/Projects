//////////////////////////////////////////////////////////////////
//Original Author: Adrian Arias
//Date Created: 8/27/2020
//Version: Alpha Version
//Date Last Modified: 9/11/2020
//Modified by: Adrian Arias
//Modification log: Added mod log
//////////////////////////////////////////////////////////////////
function myFunction() {
  alert("By clicking OK you're agreeing you are 18 or older");
}
