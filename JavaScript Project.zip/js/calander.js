//////////////////////////////////////////////////////////////////
//Original Author: Adrian Arias
//Date Created: 8/27/2020
//Version: Alpha Version
//Date Last Modified: 9/11/2020
//Modified by: Adrian Arias
//Modification log: Added mod log and calander
//////////////////////////////////////////////////////////////////

var $ = function (id) {
  return document.getElementById(id);
};

var getMonthText = function (currentMonth) {
  if (currentMonth === 0) {
    return "January";
  } else if (currentMonth === 1) {
    return "February";
  } else if (currentMonth === 2) {
    return "March";
  } else if (currentMonth === 3) {
    return "April";
  } else if (currentMonth === 4) {
    return "May";
  } else if (currentMonth === 5) {
    return "June";
  } else if (currentMonth === 6) {
    return "July";
  } else if (currentMonth === 7) {
    return "August";
  } else if (currentMonth === 8) {
    return "September";
  } else if (currentMonth === 9) {
    return "October";
  } else if (currentMonth === 10) {
    return "November";
  } else if (currentMonth === 11) {
    return "December";
  }
};

var getLastDayofMonth = function (currentMonth) {
  var dt = new Date();
  dt.setMonth(currentMonth + 1);
  dt.setDate(0);
  return dt.getDate();
};

window.onload = function () {
  var today = new Date();
  var thisMonth = today.getMonth();

  $("month_year").firstChild.nodeValue =
    getMonthText(thisMonth) + " " + today.getFullYear();

  var lastDayofMonth = getLastDayofMonth(thisMonth);
  var rows = $("calendar").innerHTML;

  var date;
  var day;
  var start;

  for (var i = 0; i < lastDayofMonth; i++) {
    today.setDate(i + 1);

    date = today.getDate();
    day = today.getDay();

    if (date === 1 || day === 0) {
      rows = rows.concat("<tr>");
    }

    if (date === 1) {
      start = 0;
      while (start < day) {
        rows = rows.concat("<td></td>");
        start++;
      }
    }

    rows = rows.concat("<td>", date, "</td>");

    if (date === lastDayofMonth) {
      start = day;
      while (start < 6) {
        rows = rows.concat("<td></td>");
        start++;
      }
    }

    if (date === lastDayofMonth || day === 6) {
      rows = rows.concat("</tr>");
    }
  }
  $("calendar").innerHTML = rows;
};
