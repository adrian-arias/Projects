

<!----------------------------------------------------------------------------------------------------------------
--
#Original Author: Adrian Arias                                      #
#Date Created: 10/27/2020                                         #
#Version: Final                                                   #
#Date Last Modified: 10/27/2020                               #
#Modified by: Adrian Arias                                          #
#Modification log: Added Bootstrap 4 template                                  #
 --
------------------------------------------------------------------------------------------------------------------>



<template>
  <body id="page-top">
    <!-- Navigation-->
    <nav
      class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top"
      id="sideNav"
    >
      <a class="navbar-brand js-scroll-trigger" href="#page-top">
        <span class="d-block d-lg-none">Adrian Arias</span>
        <span class="d-none d-lg-block"
          ><img
            class="img-fluid img-profile rounded-circle mx-auto mb-2"
            src="assets/profile.jpg"
            alt=""
        /></span>
      </a>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#about">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#experience"
              >Experience</a
            >
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#education"
              >Education</a
            >
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#skills">Skills</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#interests"
              >Interests</a
            >
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#awards">Awards</a>
          </li>
        </ul>
      </div>
    </nav>
    <!-- Page Content-->
    <div class="container-fluid p-0">
      <!-- About-->
      <section class="resume-section" id="about">
        <div class="resume-section-content">
          <h1 class="mb-0">
            Adrian
            <span class="text-primary">Arias</span>
          </h1>
          <div class="subheading mb-5">
            1107 Sunshine Ave · Wilder, ID 83676 · (208) 965-3728 ·
            <a href="mailto:adrian.arias2001@gmail.com"
              >adrian.arias2001@gmail.com</a
            >
          </div>
          <p class="lead mb-5">
            I am experienced in web app development languges such as HTML, CSS,
            SASS, and JavaScript. I am also experienced in CSS and JavaScript
            frameworks such as Bootstrap 3/4 and Vue 2/3.
          </p>
          <div class="social-icons">
            <a class="social-icon" href="#"
              ><i class="fab fa-linkedin-in"></i
            ></a>
            <a class="social-icon" href="#"><i class="fab fa-github"></i></a>
            <a class="social-icon" href="#"><i class="fab fa-twitter"></i></a>
            <a class="social-icon" href="#"
              ><i class="fab fa-facebook-f"></i
            ></a>
          </div>
        </div>
      </section>
      <hr class="m-0" />
      <!-- Experience-->
      <section class="resume-section" id="experience">
        <div class="resume-section-content">
          <h2 class="mb-5">Experience</h2>
          <div
            class="d-flex flex-column flex-md-row justify-content-between mb-5"
          >
            <div class="flex-grow-1">
              <h3 class="mb-0">General Labor</h3>
              <div class="subheading mb-3">
                Custom Roto Molding - Caldwell, ID
              </div>
              <p>
                All worked all around the warehouse. I did tasks like deburr the
                plastic molds with hand tools. I also mixed the plastic powder
                add color into large box with pallet and moved them around with
                a pallet jack. Other tasks include removing/adding molds, moving
                heavy objects, and strap boxes on pallets.
              </p>
            </div>
            <div class="flex-shrink-0">
              <span class="text-primary">June 2020 - August 2020</span>
            </div>
          </div>
          <div
            class="d-flex flex-column flex-md-row justify-content-between mb-5"
          >
            <div class="flex-grow-1">
              <h3 class="mb-0">General Labor</h3>
              <div class="subheading mb-3">
                Caldwell Orchards - Caldwell, ID
              </div>
              <p>
                My job was to collect various types of orchard fruits off the
                tress using a ladder and a tub that attached to your back. Lots
                of heavy lifting, climbing, and walking.
              </p>
            </div>
            <div class="flex-shrink-0">
              <span class="text-primary">June 2019 - July 2019</span>
            </div>
          </div>
          <div
            class="d-flex flex-column flex-md-row justify-content-between mb-5"
          >
            <div class="flex-grow-1">
              <h3 class="mb-0">General Labor</h3>
              <div class="subheading mb-3">Crookham Company - Caldwell, ID</div>
              <p>
                My job was to check each corn plant and detassel them. This job
                required lots of walking and patience. We would be taken to
                different spots everyday.
              </p>
            </div>
            <div class="flex-shrink-0">
              <span class="text-primary">June 2020 - July 2020</span>
            </div>
          </div>
          <div class="d-flex flex-column flex-md-row justify-content-between">
            <div class="flex-grow-1">
              <h3 class="mb-0">General Labor</h3>
              <div class="subheading mb-3">
                Caldwell Orchards - Caldwell, ID
              </div>
              <p>
                My job was to collect various types of orchard fruits off the
                tress using a ladder and a tub that attached to your back. Lots
                of heavy lifting, climbing, and walking.
              </p>
            </div>
            <div class="flex-shrink-0">
              <span class="text-primary">June 2017 - July 2017</span>
            </div>
          </div>
        </div>
      </section>
      <hr class="m-0" />
      <!-- Education-->
      <section class="resume-section" id="education">
        <div class="resume-section-content">
          <h2 class="mb-5">Education</h2>
          <div
            class="d-flex flex-column flex-md-row justify-content-between mb-5"
          >
            <div class="flex-grow-1">
              <h3 class="mb-0">College of Western Idaho</h3>
              <div class="subheading mb-3">Associate of Applied Science</div>
              <div>Software Development</div>
              <p>GPA: 3.26</p>
            </div>
            <div class="flex-shrink-0">
              <span class="text-primary">August 2019 - Current</span>
            </div>
          </div>
          <div class="d-flex flex-column flex-md-row justify-content-between">
            <div class="flex-grow-1">
              <h3 class="mb-0">Wilder High School</h3>
              <div class="subheading mb-3"></div>
              <p>GPA: 3.33</p>
            </div>
            <div class="flex-shrink-0">
              <span class="text-primary">August 2015 - May 2019</span>
            </div>
          </div>
        </div>
      </section>
      <hr class="m-0" />
      <!-- Skills-->
      <section class="resume-section" id="skills">
        <div class="resume-section-content">
          <h2 class="mb-5">Skills</h2>
          <div class="subheading mb-3">Programming Languages & Tools</div>
          <ul class="list-inline dev-icons">
            <li class="list-inline-item"><i class="fab fa-html5"></i></li>
            <li class="list-inline-item"><i class="fab fa-css3-alt"></i></li>
            <li class="list-inline-item"><i class="fab fa-js-square"></i></li>
            <li class="list-inline-item"><i class="fab fa-angular"></i></li>
            <li class="list-inline-item"><i class="fab fa-react"></i></li>
            <li class="list-inline-item"><i class="fab fa-sass"></i></li>
          </ul>
          <div class="subheading mb-3">Workflow</div>
          <ul class="fa-ul mb-0">
            <li>
              <span class="fa-li"><i class="fas fa-check"></i></span>
              Multitasker
            </li>
            <li>
              <span class="fa-li"><i class="fas fa-check"></i></span>
              Testing & Debugging
            </li>
            <li>
              <span class="fa-li"><i class="fas fa-check"></i></span>
              Team player
            </li>
            <li>
              <span class="fa-li"><i class="fas fa-check"></i></span>
              Operating 3D Printers
            </li>
          </ul>
        </div>
      </section>
      <hr class="m-0" />
      <!-- Interests-->
      <section class="resume-section" id="interests">
        <div class="resume-section-content">
          <h2 class="mb-5">Interests</h2>
          <p>
            Apart from being a web developer, I enjoy most of my time
            exercising. I like to play all types of generes.During the warmer
            months here in Idaho, I enjoy biking, hiking, and camping.
          </p>
          <p class="mb-0">
            I also like to get involved with all types of technology. The big
            one is working with 3D Printers. I have made and built all types of
            figures and useful tools. I also like to play all types of video
            games no matter the genre.
          </p>
        </div>
      </section>
      <hr class="m-0" />
      <!-- Awards-->
      <section class="resume-section" id="awards">
        <div class="resume-section-content">
          <h2 class="mb-5">Awards & Certifications</h2>
          <ul class="fa-ul mb-0">
            <li>
              <span class="fa-li"
                ><i class="fas fa-trophy text-warning"></i
              ></span>
              Nation Carreer Readiness Certificate - Feb 2019
            </li>
          </ul>
        </div>
      </section>
    </div>
  </body>
</template>

<script>
import HelloWorldVue from "./components/HelloWorld.vue";
export default {
  name: "App",
  components: {
    HelloWorld: HelloWorldVue,
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
